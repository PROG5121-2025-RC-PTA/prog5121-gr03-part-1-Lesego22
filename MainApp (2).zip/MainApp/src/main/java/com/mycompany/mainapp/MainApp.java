/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainapp;

import javax.swing.JOptionPane;

/**
 *
 * @author leseg
 */
public class MainApp {
    private Login login;
    private Message messageSystem;

    public MainApp() {
        login = new Login();
        messageSystem = new Message();
    }

    public void run() {
        // Simple login 
        login = new Login("test_", "Password1!", "+27765196478", "Lesego", "Leso");
        
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        
        if (!login.loginUser(username, password)) {
            JOptionPane.showMessageDialog(null, "Login failed!");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat");

        boolean running = true;
        while (running) {
            String[] options = {
                "Send Messages", 
                "Show recently sent messages", 
                "Show stored messages", 
                "Display Message Report",
                "Search Messages",
                "Message Analytics",
                "Delete Message",
                "Quit"
            };
            
            int choice = JOptionPane.showOptionDialog(
                null,
                "Choose an option:",
                "QuickChat Menu",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
            );

            switch (choice) {
                case 0: // Send Messages
                    sendMessages();
                    break;
                case 1: // Show recently sent messages
                    JOptionPane.showMessageDialog(null, messageSystem.displaySentMessageDetails());
                    break;
                case 2: // Show stored messages
                    JOptionPane.showMessageDialog(null, messageSystem.displayStoredMessages());
                    break;
                case 3: // Display Message Report
                    JOptionPane.showMessageDialog(null, messageSystem.displayMessageReport());
                    break;
                case 4: // Search Messages
                    searchMessagesMenu();
                    break;
                case 5: // Message Analytics
                    messageAnalyticsMenu();
                    break;
                case 6: // Delete Message
                    deleteMessageMenu();
                    break;
                case 7: // Quit
                case -1: // Window closed
                    running = false;
                    break;
            }
        }

        // Display total messages sent
        JOptionPane.showMessageDialog(null, 
            "Total messages sent: " + messageSystem.returnTotalMessages());
    }

    private void sendMessages() {
        String numMessagesStr = JOptionPane.showInputDialog("How many messages do you want to send?");
        try {
            int numMessages = Integer.parseInt(numMessagesStr);
            
            for (int i = 0; i < numMessages; i++) {
                String recipient = JOptionPane.showInputDialog("Enter recipient cell number:");
                String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                
                if (recipient != null && message != null) {
                    messageSystem.sendMessage(recipient, message, i + 1);
                }
            }
            
            // Display all sent messages
            JOptionPane.showMessageDialog(null, messageSystem.printMessages());
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number entered.");
        }
    }

    private void searchMessagesMenu() {
        String[] searchOptions = {
            "Search by Message ID",
            "Search by Recipient",
            "Back to Main Menu"
        };
        
        int choice = JOptionPane.showOptionDialog(
            null,
            "Choose search option:",
            "Search Messages",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            searchOptions,
            searchOptions[0]
        );
        
        switch (choice) {
            case 0: // Search by Message ID
                String messageID = JOptionPane.showInputDialog("Enter Message ID:");
                if (messageID != null) {
                    JOptionPane.showMessageDialog(null, 
                        messageSystem.searchMessageByID(messageID));
                }
                break;
            case 1: // Search by Recipient  
                String recipient = JOptionPane.showInputDialog("Enter recipient cell number:");
                if (recipient != null) {
                    JOptionPane.showMessageDialog(null, 
                        messageSystem.searchMessagesByRecipient(recipient));
                }
                break;
            case 2: // Back to main menu
                break;
        }
    }

    private void messageAnalyticsMenu() {
        String[] analyticsOptions = {
            "Show Longest Message",
            "Show Sent Messages Details", 
            "Back to Main Menu"
        };
        
        int choice = JOptionPane.showOptionDialog(
            null,
            "Choose analytics option:",
            "Message Analytics",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            analyticsOptions,
            analyticsOptions[0]
        );
        
        switch (choice) {
            case 0: // Show Longest Message
                JOptionPane.showMessageDialog(null, 
                    messageSystem.displayLongestMessage());
                break;
            case 1: // Show Sent Messages Details
                JOptionPane.showMessageDialog(null, 
                    messageSystem.displaySentMessageDetails());
                break;
            case 2: // Back to main menu
                break;
        }
    }

    private void deleteMessageMenu() {
        String messageHash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
        if (messageHash != null && !messageHash.trim().isEmpty()) {
            String result = messageSystem.deleteMessageByHash(messageHash);
            JOptionPane.showMessageDialog(null, result);
        }
    }

    public static void main(String[] args) {
        new MainApp().run();
    }
}