/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainapp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author leseg
 */
public class Message {
    private ArrayList<String> messageIDs;
    private ArrayList<String> messageHashes;
    private ArrayList<String> recipients;
    private ArrayList<String> messages;
    private ArrayList<String> messageStatuses;
    
    // New arrays for Part 3
    private ArrayList<String> sentMessages;
    private ArrayList<String> disregardedMessages;
    private ArrayList<String> storedMessages;
    
    private int totalMessages;
    private Random random;

    public Message() {
        messageIDs = new ArrayList<>();
        messageHashes = new ArrayList<>();
        recipients = new ArrayList<>();
        messages = new ArrayList<>();
        messageStatuses = new ArrayList<>();
        
        // Initialize new arrays
        sentMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        
        totalMessages = 0;
        random = new Random();
    }

    public boolean checkMessageID(String messageID) {
        return messageID.length() == 10;
    }

    public boolean checkRecipientCell(String cellNumber) {
        // Reusing the pattern from Login class
        String pattern = "^\\+27[0-9]{9}$";
        return java.util.regex.Pattern.matches(pattern, cellNumber) || 
               (cellNumber.length() <= 10 && cellNumber.matches("^[0-9+]+$"));
    }

    public String createMessageHash(String messageID, int messageNumber, String message) {
        String[] words = message.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String firstTwoDigits = messageID.length() >= 2 ? messageID.substring(0, 2) : "00";
        
        return (firstTwoDigits + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    private String generateMessageID() {
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    public String sendMessage(String recipient, String messageText, int messageNumber) {
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }

        if (!checkRecipientCell(recipient)) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }

        String messageID = generateMessageID();
        String messageHash = createMessageHash(messageID, messageNumber, messageText);

        // Display message options
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(
            null,
            "Message Details:\nMessage ID: " + messageID + 
            "\nMessage Hash: " + messageHash + 
            "\nRecipient: " + recipient + 
            "\nMessage: " + messageText,
            "Message Options",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
        );

        String status = "";
        switch (choice) {
            case 0: // Send Message
                messageIDs.add(messageID);
                messageHashes.add(messageHash);
                recipients.add(recipient);
                messages.add(messageText);
                messageStatuses.add("Sent");
                sentMessages.add(messageText); // Add to sent messages array
                totalMessages++;
                status = "Message successfully sent.";
                break;
            case 1: // Disregard Message
                disregardedMessages.add(messageText); // Add to disregarded messages array
                status = "Press 0 to delete message.";
                break;
            case 2: // Store Message
                storeMessage(messageID, messageHash, recipient, messageText);
                storedMessages.add(messageText); // Add to stored messages array
                status = "Message successfully stored.";
                break;
            default:
                status = "No action taken.";
        }

        // Display full message details after action
        JOptionPane.showMessageDialog(null, 
            "Message ID: " + messageID + 
            "\nMessage Hash: " + messageHash + 
            "\nRecipient: " + recipient + 
            "\nMessage: " + messageText + 
            "\nStatus: " + status);

        return status;
    }

    // Method created with ChatGPT assistance (OpenAI, 2024)
    public void storeMessage(String messageID, String messageHash, String recipient, String messageText) {
        try {
            FileWriter writer = new FileWriter("stored_messages.json", true);
            
            // Check if file is empty to add proper JSON structure
            java.io.File file = new java.io.File("stored_messages.json");
            if (file.length() == 0) {
                writer.write("[\n");
            } else {
                writer.write(",\n");
            }
            
            writer.write("  {\n");
            writer.write("    \"messageID\": \"" + messageID + "\",\n");
            writer.write("    \"messageHash\": \"" + messageHash + "\",\n");
            writer.write("    \"recipient\": \"" + recipient + "\",\n");
            writer.write("    \"message\": \"" + messageText.replace("\"", "\\\"") + "\",\n");
            writer.write("    \"timestamp\": \"" + java.time.LocalDateTime.now() + "\"\n");
            writer.write("  }\n");
            writer.write("]");
            writer.close();
            
            System.out.println("Message stored successfully in JSON format.");
        } catch (IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // Method to read JSON file - Created with ChatGPT assistance (OpenAI, 2024)
    public ArrayList<String> readStoredMessagesFromJSON() {
        ArrayList<String> storedMessagesFromFile = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("stored_messages.json"));
            String line;
            StringBuilder jsonContent = new StringBuilder();
            
            while ((line = reader.readLine()) != null) {
                jsonContent.append(line);
            }
            reader.close();
            
            // Simple JSON parsing (basic implementation)
            String content = jsonContent.toString();
            if (content.contains("\"message\":")) {
                String[] parts = content.split("\"message\":");
                for (int i = 1; i < parts.length; i++) {
                    String messagePart = parts[i];
                    int start = messagePart.indexOf("\"") + 1;
                    int end = messagePart.indexOf("\",", start);
                    if (end == -1) end = messagePart.indexOf("\"", start);
                    
                    if (start > 0 && end > start) {
                        String message = messagePart.substring(start, end);
                        storedMessagesFromFile.add(message.replace("\\\"", "\""));
                    }
                }
            }
            
        } catch (IOException e) {
            System.out.println("Error reading stored messages: " + e.getMessage());
        }
        
        return storedMessagesFromFile;
    }

    // Method to display stored messages from JSON
    public String displayStoredMessages() {
        ArrayList<String> storedMessagesFromFile = readStoredMessagesFromJSON();
        if (storedMessagesFromFile.isEmpty()) {
            return "No stored messages found.";
        }
        
        StringBuilder result = new StringBuilder("Stored Messages from JSON:\n");
        for (int i = 0; i < storedMessagesFromFile.size(); i++) {
            result.append((i + 1)).append(". ").append(storedMessagesFromFile.get(i)).append("\n");
        }
        return result.toString();
    }

    // NEW METHODS FOR PART 3

    // Display sender and recipient of all sent messages
    public String displaySentMessageDetails() {
        if (sentMessages.isEmpty()) {
            return "No sent messages found.";
        }
        
        StringBuilder result = new StringBuilder("Sent Messages Details:\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            result.append("Message ").append(i + 1).append(":\n");
            result.append("Recipient: ").append(recipients.get(i)).append("\n");
            result.append("Message: ").append(sentMessages.get(i)).append("\n\n");
        }
        return result.toString();
    }

    // Display the longest sent message
    public String displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            return "No sent messages to analyze.";
        }
        
        String longestMessage = sentMessages.get(0);
        for (String message : sentMessages) {
            if (message.length() > longestMessage.length()) {
                longestMessage = message;
            }
        }
        
        return "Longest message: " + longestMessage;
    }

    // Search for message by ID and display recipient and message
    public String searchMessageByID(String messageID) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(messageID)) {
                return "Message found:\nRecipient: " + recipients.get(i) + 
                       "\nMessage: " + messages.get(i);
            }
        }
        return "Message ID not found.";
    }

    // Search messages by recipient
    public String searchMessagesByRecipient(String recipient) {
        StringBuilder result = new StringBuilder();
        boolean found = false;
        
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipient)) {
                if (!found) {
                    result.append("Messages for recipient ").append(recipient).append(":\n");
                    found = true;
                }
                result.append("- ").append(messages.get(i)).append("\n");
            }
        }
        
        if (!found) {
            return "No messages found for recipient: " + recipient;
        }
        
        return result.toString();
    }

    // Delete message using message hash
    public String deleteMessageByHash(String messageHash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(messageHash)) {
                String deletedMessage = messages.get(i);
                
                // Remove from all arrays
                messageIDs.remove(i);
                messageHashes.remove(i);
                recipients.remove(i);
                messages.remove(i);
                messageStatuses.remove(i);
                
                // Also remove from sent messages if it was sent
                if (sentMessages.contains(deletedMessage)) {
                    sentMessages.remove(deletedMessage);
                }
                
                totalMessages--;
                return "Message \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // Display full message report
    public String displayMessageReport() {
        if (messageIDs.isEmpty()) {
            return "No messages to report.";
        }
        
        StringBuilder report = new StringBuilder("MESSAGE REPORT\n");
        report.append("=================\n\n");
        
        for (int i = 0; i < messageIDs.size(); i++) {
            report.append("Message ").append(i + 1).append(":\n");
            report.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
            report.append("Recipient: ").append(recipients.get(i)).append("\n");
            report.append("Message: ").append(messages.get(i)).append("\n");
            report.append("Status: ").append(messageStatuses.get(i)).append("\n");
            report.append("-------------------\n\n");
        }
        
        return report.toString();
    }

    // Getters for arrays (for testing purposes)
    public ArrayList<String> getSentMessages() {
        return sentMessages;
    }
    
    public ArrayList<String> getDisregardedMessages() {
        return disregardedMessages;
    }
    
    public ArrayList<String> getStoredMessages() {
        return storedMessages;
    }
    
    public ArrayList<String> getMessageHashes() {
        return messageHashes;
    }
    
    public ArrayList<String> getMessageIDs() {
        return messageIDs;
    }

    public String printMessages() {
        if (messageIDs.isEmpty()) {
            return "No messages sent yet.";
        }

        StringBuilder allMessages = new StringBuilder("Sent Messages:\n");
        for (int i = 0; i < messageIDs.size(); i++) {
            allMessages.append("Message ").append(i + 1).append(":\n");
            allMessages.append("ID: ").append(messageIDs.get(i)).append("\n");
            allMessages.append("Hash: ").append(messageHashes.get(i)).append("\n");
            allMessages.append("Recipient: ").append(recipients.get(i)).append("\n");
            allMessages.append("Message: ").append(messages.get(i)).append("\n");
            allMessages.append("Status: ").append(messageStatuses.get(i)).append("\n\n");
        }
        return allMessages.toString();
    }

    public int returnTotalMessages() {
        return totalMessages;
    }

    // Validation methods for testing
    public String validateMessage(String message) {
        if (message.length() > 250) {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    public String validateRecipient(String cellNumber) {
        if (checkRecipientCell(cellNumber)) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }
}