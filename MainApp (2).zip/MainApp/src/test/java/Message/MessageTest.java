/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Message;

import com.mycompany.mainapp.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author leseg
 */
public class MessageTest {
    private Message message = new Message();

    @Test
    public void testMessageLengthValid() {
        String result = message.validateMessage("Hi Mike, can you join us for dinner tonight");
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testMessageLengthInvalid() {
        String longMessage = "This is a very long message that exceeds the 250 character limit. " +
                           "It should trigger an error message indicating that the message is too long. " +
                           "We need to make sure this message is definitely longer than 250 characters to test properly.";
        String result = message.validateMessage(longMessage);
        assertTrue(result.contains("Message exceeds 250 characters"));
    }

    @Test
    public void testRecipientNumberValid() {
        String result = message.validateRecipient("+27718693002");
        assertEquals("Cell phone number successfully captured.", result);
    }

    @Test
    public void testRecipientNumberInvalid() {
        String result = message.validateRecipient("08575975889");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }

    @Test
    public void testMessageHashGeneration() {
        String hash = message.createMessageHash("1234567890", 0, "HI TONIGHT");
        assertEquals("12:0:HITONIGHT", hash);
    }

    @Test
    public void testMessageIDCreation() {
        String messageID = "1234567890";
        assertTrue(message.checkMessageID(messageID));
    }

    @Test
    public void testTotalMessagesCounter() {
        int initialCount = message.returnTotalMessages();
        // This would need to be tested with actual message sending in integration tests
        assertTrue(initialCount >= 0);
    }
}