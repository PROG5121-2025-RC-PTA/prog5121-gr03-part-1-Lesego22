/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.mainapp;

import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author leseg
 */
public class MessageTestPart3 {
    
    private Message messageSystem;
    
    @BeforeEach
    public void setUp() {
        messageSystem = new Message();
        
        // Test Data Message 1 - Sent
        messageSystem.getSentMessages().add("Did you get the cake?");
        messageSystem.getMessageIDs().add("1234567890");
        messageSystem.getMessageHashes().add("12:1:DIDCAKE?");
        
        // Test Data Message 2 - Stored  
        messageSystem.getStoredMessages().add("Where are you? You are late! I have asked you to be on time.");
        
        // Test Data Message 3 - Disregarded
        messageSystem.getDisregardedMessages().add("Yohoooo, I am at your gate.");
        
        // Test Data Message 4 - Sent
        messageSystem.getSentMessages().add("It is dinner time !");
        messageSystem.getMessageIDs().add("0838884567");
        messageSystem.getMessageHashes().add("08:4:ITTIME!");
        
        // Test Data Message 5 - Stored
        messageSystem.getStoredMessages().add("Ok, I am leaving without you.");
    }
    
    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        // Test that sent messages array contains expected data
        ArrayList<String> sentMessages = messageSystem.getSentMessages();
        
        assertTrue(sentMessages.contains("Did you get the cake?"));
        assertTrue(sentMessages.contains("It is dinner time !"));
        
        // Test exact expected output from POE
        String expected1 = "Did you get the cake?";
        String expected2 = "It is dinner time !";
        
        assertEquals(expected1, sentMessages.get(0));
        assertEquals(expected2, sentMessages.get(1));
    }
    
    @Test
    public void testDisplayLongestMessage() {
        // Test Data: messages 1-4 
        messageSystem.getSentMessages().add("Where are you? You are late! I have asked you to be on time.");
        
        String result = messageSystem.displayLongestMessage();
        String expected = "Longest message: Where are you? You are late! I have asked you to be on time.";
        
        assertEquals(expected, result);
    }
    
    @Test
    public void testSearchForMessageID() {
        
        String result = messageSystem.searchMessageByID("0838884567");
       
        assertTrue(result.contains("It is dinner time !"));
    }
    
    @Test
    public void testSearchMessagesByRecipient() {
        ArrayList<String> testRecipients = new ArrayList<>();
        testRecipients.add("+27838884567");
        testRecipients.add("+27838884567");
        
        ArrayList<String> testMessages = new ArrayList<>();
        testMessages.add("Where are you? You are late! I have asked you to be on time.");
        testMessages.add("Ok, I am leaving without you.");
        
        // For this test, we'll verify the method logic by checking if it can find messages
        String result = messageSystem.searchMessagesByRecipient("+27838884567");
        
        // Since we don't have actual data stored, we expect "No messages found"
        assertTrue(result.contains("No messages found") || result.contains("Messages for recipient"));
    }
    
    @Test
    public void testDeleteMessageByHash() {
        // Add a test message with hash for deletion
        messageSystem.getMessageHashes().add("TEST:HASH:123");
        messageSystem.getMessageIDs().add("1234567890");
        
        String testHash = "TEST:HASH:123";
        String result = messageSystem.deleteMessageByHash(testHash);
       
        assertTrue(result.contains("successfully deleted") || result.contains("not found"));
    }
    
    @Test
    public void testDisplayReport() {
        
        String result = messageSystem.displayMessageReport();
        
        assertTrue(result.contains("MESSAGE REPORT") || result.contains("No messages to report"));
        if (!result.contains("No messages to report")) {
            assertTrue(result.contains("Message Hash:"));
            assertTrue(result.contains("Recipient:"));
            assertTrue(result.contains("Message:"));
        }
    }
    
    @Test
    public void testMessageValidation() {
        // Test message length validation
        String shortMessage = "Hello";
        String longMessage = "This is a very long message that exceeds the 250 character limit. " +
                            "It should return an error message indicating that the message is too long. " +
                            "The system should calculate exactly how many characters over the limit it is. " +
                            "This message is designed to be significantly longer than 250 characters to test the validation properly.";
        
        String result1 = messageSystem.validateMessage(shortMessage);
        String result2 = messageSystem.validateMessage(longMessage);
        
        assertEquals("Message ready to send.", result1);
        assertTrue(result2.contains("Message exceeds 250 characters"));
    }
    
    @Test
    public void testRecipientValidation() {
        // Test recipient validation
        String validRecipient = "+27838884567";
        String invalidRecipient = "123";
        
        String result1 = messageSystem.validateRecipient(validRecipient);
        String result2 = messageSystem.validateRecipient(invalidRecipient);
        
        assertEquals("Cell phone number successfully captured.", result1);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result2);
    }
    
    @Test
    public void testArraysInitialization() {
        // Test that all arrays are properly initialized
        assertNotNull(messageSystem.getSentMessages());
        assertNotNull(messageSystem.getDisregardedMessages());
        assertNotNull(messageSystem.getStoredMessages());
        assertNotNull(messageSystem.getMessageHashes());
        assertNotNull(messageSystem.getMessageIDs());
    }
}