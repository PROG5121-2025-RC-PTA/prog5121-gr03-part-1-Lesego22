/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChat.Java;

/**
 *
 * @author leseg
 */
// Import necessary libraries for JUnit testing
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {
    
    @Test
    public void testCheckUserName_Successful() {
        // Test case for correct username format
        Login login = new Login();
        login.setUsername("kyl_1");
        
        assertTrue(login.checkUserName());
    }
    
    @Test
    public void testCheckUserName_Unsuccessful() {
        // Test case for incorrect username format
        Login login = new Login();
        login.setUsername("kyle!!!!!!!"); 
        
        assertFalse(login.checkUserName());
    }
    
    @Test
    public void testCheckPasswordComplexity_Successful() {
        // Test case for password that meets complexity requirements
        Login login = new Login();
        login.setPassword("Ch&&sec@ke99!");
        
        assertTrue(login.checkPasswordComplexity());
    }
    
    @Test
    public void testCheckPasswordComplexity_Unsuccessful() {
        // Test case for password that does not meet complexity requirements
        Login login = new Login();
        login.setPassword("password");
        
        assertFalse(login.checkPasswordComplexity());
    }
    
    @Test
    public void testCheckCellPhoneNumber_Successful() {
        // Test case for correctly formatted cell phone number
        Login login = new Login();
        login.setCellNumber("+27838968976");
        
        assertTrue(login.checkCellPhoneNumber());
    }
    
    @Test
    public void testCheckCellPhoneNumber_Unsuccessful() {
        // Test case for incorrectly formatted cell phone number
        Login login = new Login();
        login.setCellNumber("08966553");
        
        assertFalse(login.checkCellPhoneNumber());
    }
    
    @Test
    public void testRegisterUser_AllValid() {
        // Test case for successful registration with all valid information
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellNumber("+27838968976");
        
        String expected = "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
        assertEquals(expected, login.registerUser());
    }
    
    @Test
    public void testRegisterUser_InvalidUsername() {
        // Test case for registration with invalid username
        Login login = new Login();
        login.setUsername("kyle!!!!!!!"); 
        login.setPassword("Ch&&sec@ke99!");
        login.setCellNumber("+27838968976");
        
        String expected = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        assertEquals(expected, login.registerUser());
    }
    
    @Test
    public void testRegisterUser_InvalidPassword() {
        // Test case for registration with invalid password
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("password");
        login.setCellNumber("+27838968976");
        
        String expected = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        assertEquals(expected, login.registerUser());
    }
    
    @Test
    public void testRegisterUser_InvalidCellNumber() {
        // Test case for registration with invalid cell phone number
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setCellNumber("08966553");
        
        String expected = "Cell phone number incorrectly formatted or does not contain international code.";
        assertEquals(expected, login.registerUser());
    }
    
    @Test
    public void testLoginUser_Successful() {
        // Test for successful login
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setLoginUsername("kyl_1");
        login.setLoginPassword("Ch&&sec@ke99!");
        
        assertTrue(login.loginUser());
    }
    
    @Test
    public void testLoginUser_Unsuccessful() {
        // Test for unsuccessful login
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setLoginUsername("wrong");
        login.setLoginPassword("wrong");
        
        assertFalse(login.loginUser());
    }
    
    @Test
    public void testReturnLoginStatus_Successful() {
        // Test for successful login status message
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setFirstName("Kyle");
        login.setLastName("Smith");
        login.setLoginUsername("kyl_1");
        login.setLoginPassword("Ch&&sec@ke99!");
        login.loginUser();
        
        String expected = "Welcome Kyle, Smith it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus());
    }
    
    @Test
    public void testReturnLoginStatus_Unsuccessful() {
        // Test for unsuccessful login status message
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        login.setLoginUsername("wrong");
        login.setLoginPassword("wrong");
        login.loginUser();
        
        String expected = "Username or password incorrect, please try again.";
        assertEquals(expected, login.returnLoginStatus());
    }
}