/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentscores;

import java.util.Scanner;

/**
 *
 * @author leseg
 */
public class StudentScores {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int[] scores = new int[10];
        for(int i = 0; i < scores.length; i++){
        System.out.print(" : " +  "Please enter score for a student" + (i + 1));
        
        scores[i] = input.nextInt();
        
        //Check if the students passed or failed
        int passes = 0;
        int fails = 0;
        for(int score : scores){
            if (score >= 50){
                passes++;
            }else{
                fails++;
            }
            }
        double sum = 0;
        for (int score : scores){
            sum += score;
        }
        double average = sum/scores.length;
        //Lowest score
        int lowest = scores[0];
        for (int score : scores){
            if (score < lowest){
                lowest = score;
            }
        }
        int above75 = 0;
        for (int score : scores){
            if (score > 75){
                above75++;
            }
        }
        //Display results
            System.out.println("Please enter number of students that passed: " + passes);
            System.out.println("Please enter number of students that failed: " + fails);
            System.out.printf("Average score: %.1f\n" , average);
            System.out.println("Lowest score: " + lowest);
            System.out.println("Number of students scoring above 75: " + above75);
            
                 input.close();
            
        }
        
        
    }
}
